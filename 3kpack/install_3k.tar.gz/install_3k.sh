#!/bin/bash

# Vérifier si le fichier config_light1 existe
if [ -f config_light1 ]; then
    # Créer le répertoire ~/.kube s'il n'existe pas
    mkdir -p ~/.kube

    # Déplacer le fichier config_light1 dans ~/.kube
    mv config_light1 ~/.kube/

    # Vérifier si le déplacement a réussi
    if [ $? -eq 0 ]; then
        echo "Le fichier config_light1 a été enregistré avec succès dans ~/.kube."
    else
        echo "Une erreur s'est produite lors de l'enregistrement du fichier config_light1."
    fi
else
    echo "Le fichier config_light1 n'existe pas. L'enregistrement du fichier config_light1 est ignoré."
fi

# Vérifier si le fichier k9s_Linux_amd64.tar.gz existe
if [ -f k9s_Linux_amd64.tar.gz ]; then
    # Extraire le contenu du fichier tar.gz
    tar -xzf k9s_Linux_amd64.tar.gz

    # Déplacer l'exécutable K9s dans /usr/local/bin
    sudo mv k9s /usr/local/bin

    # Vérifier si l'installation a réussi
    if [ $? -eq 0 ]; then
        echo "K9s a été installé avec succès dans /usr/local/bin."
    else
        echo "Une erreur s'est produite lors de l'installation de K9s."
    fi
else
    echo "Le fichier k9s_Linux_amd64.tar.gz n'existe pas. L'installation de K9s est ignorée."
fi

# Vérifier si le fichier kubie-linux-amd64 existe
if [ -f kubie-linux-amd64 ]; then
    # Renommer le fichier kubie-linux-amd64 en kubie
    mv kubie-linux-amd64 kubie

    # Déplacer l'exécutable Kubie dans /usr/local/bin
    sudo mv kubie /usr/local/bin

    # Rendre l'exécutable Kubie exécutable
    sudo chmod +x /usr/local/bin/kubie

    # Vérifier si l'installation a réussi
    if [ $? -eq 0 ]; then
        echo "Kubie a été installé avec succès dans /usr/local/bin."
    else
        echo "Une erreur s'est produite lors de l'installation de Kubie."
    fi
else
    echo "Le fichier kubie-linux-amd64 n'existe pas. L'installation de Kubie est ignorée."
fi

